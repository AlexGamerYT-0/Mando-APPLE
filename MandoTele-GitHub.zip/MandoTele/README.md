# Mando (tele LG)
App SwiftUI que controla una LG webOS por wifi con aspecto de Siri Remote.

1. Sube esta carpeta a tu repo de GitHub (rama main).
2. Actions → "Build IPA" → descarga el artefacto MandoTele-ipa (.ipa sin firmar).
3. Firma/instala el .ipa con tu método habitual (AltStore, Sideloadly...).
4. En la app: pon la IP de la tele y acepta el aviso en la pantalla.
