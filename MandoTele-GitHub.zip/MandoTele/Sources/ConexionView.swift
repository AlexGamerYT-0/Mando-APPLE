import SwiftUI

struct ConexionView: View {
    @EnvironmentObject var tv: TVController
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Tu tele LG")) {
                    TextField("IP de la tele (ej. 192.168.1.20)", text: $tv.ip)
                        .keyboardType(.numbersAndPunctuation)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                    Button("Conectar") { tv.conectar() }
                    if tv.conectada { Button("Desconectar", role: .destructive) { tv.desconectar() } }
                    Button("Probar sin tele (modo demo)") { tv.activarDemo() }
                }
                Section(header: Text("Estado")) {
                    Text(tv.status.texto)
                }
                Section(header: Text("Cómo sacar la IP")) {
                    Text("En la tele: Ajustes → Red → Conexión Wi-Fi → Avanzado. Activa también «LG Connect Apps» en Ajustes → General. La primera vez la tele te pide aceptar el mando.")
                        .font(.footnote)
                }
            }
            .navigationTitle("Conexión")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Listo") { dismiss() } } }
            .onChange(of: tv.status) { s in if s == .conectada { dismiss() } }
        }
    }
}

struct TecladoView: View {
    @EnvironmentObject var tv: TVController
    @Environment(\.dismiss) private var dismiss
    @State private var texto = ""
    @FocusState private var foco: Bool

    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                TextField("Escribe en la tele", text: $texto)
                    .textFieldStyle(.roundedBorder)
                    .focused($foco)
                    .submitLabel(.send)
                    .onChange(of: texto) { tv.escribir($0) }
                    .onSubmit { tv.enter(); dismiss() }
                Text("Abre antes un cuadro de texto en la tele (por ejemplo, el buscador).")
                    .font(.footnote).foregroundColor(.secondary)
                Spacer()
            }
            .padding()
            .navigationTitle("Teclado")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cerrar") { dismiss() } } }
            .onAppear { foco = true }
        }
    }
}

struct AppsView: View {
    @EnvironmentObject var tv: TVController
    @Environment(\.dismiss) private var dismiss

    private let apps: [(String, String, String)] = [
        ("Netflix", "netflix", "n.circle.fill"),
        ("YouTube", "youtube.leanback.v4", "play.rectangle.fill"),
        ("Prime Video", "amazon", "a.circle.fill"),
        ("TV en directo", "com.webos.app.livetv", "tv.fill"),
        ("Navegador", "com.webos.app.browser", "safari.fill"),
        ("Ajustes", "com.webos.app.settings", "gearshape.fill")
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 100), spacing: 14)], spacing: 14) {
                    ForEach(apps, id: \.1) { app in
                        Button { tv.abrir(app.1); dismiss() } label: {
                            VStack(spacing: 8) {
                                Image(systemName: app.2).font(.system(size: 30))
                                Text(app.0).font(.footnote.weight(.semibold))
                            }
                            .frame(maxWidth: .infinity).padding(.vertical, 20)
                            .background(Color.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        }
                        .buttonStyle(PulsarStyle())
                    }
                }
                .padding()
            }
            .navigationTitle("Apps")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cerrar") { dismiss() } } }
        }
    }
}
