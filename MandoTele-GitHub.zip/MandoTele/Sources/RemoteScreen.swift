import SwiftUI
import WebOSClient

struct RemoteScreen: View {
    @EnvironmentObject var tv: TVController
    @State private var mostrarTeclado = false
    @State private var mostrarApps = false
    @State private var mostrarConexion = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 18) {
                cabecera
                Spacer(minLength: 0)
                SiriRemote()
                Spacer(minLength: 0)
                barraInferior
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 10)
        }
        .sheet(isPresented: $mostrarConexion) { ConexionView() }
        .sheet(isPresented: $mostrarTeclado) { TecladoView() }
        .sheet(isPresented: $mostrarApps) { AppsView() }
        .onAppear { if !tv.conectada && !tv.ip.isEmpty { tv.conectar() } else if tv.ip.isEmpty { mostrarConexion = true } }
    }

    // Cabecera como la app Mando de Apple: cerrar a la izquierda, nombre del dispositivo en el centro
    var cabecera: some View {
        HStack {
            Button { mostrarConexion = true } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 15, weight: .semibold))
                    .frame(width: 36, height: 36)
                    .background(Color.white.opacity(0.14), in: Circle())
            }
            Spacer()
            Button { mostrarConexion = true } label: {
                HStack(spacing: 6) {
                    Circle()
                        .fill(tv.conectada ? Color.green : Color.orange)
                        .frame(width: 8, height: 8)
                    Text(tv.tvName).font(.system(size: 16, weight: .semibold))
                    Image(systemName: "chevron.down").font(.system(size: 11, weight: .bold))
                }
                .padding(.horizontal, 14).padding(.vertical, 8)
                .background(Color.white.opacity(0.14), in: Capsule())
            }
            Spacer()
            Color.clear.frame(width: 36, height: 36)
        }
        .foregroundColor(.white)
        .padding(.top, 6)
    }

    var barraInferior: some View {
        HStack(spacing: 14) {
            pastilla("keyboard", "Teclado") { mostrarTeclado = true }
            pastilla("square.grid.2x2.fill", "Apps") { mostrarApps = true }
        }
    }

    func pastilla(_ icono: String, _ texto: String, _ accion: @escaping () -> Void) -> some View {
        Button(action: accion) {
            HStack(spacing: 8) {
                Image(systemName: icono)
                Text(texto).font(.system(size: 16, weight: .semibold))
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity).padding(.vertical, 14)
            .background(Color.white.opacity(0.14), in: Capsule())
        }
    }
}

// MARK: - Mando plateado igual que el Siri Remote
struct SiriRemote: View {
    @EnvironmentObject var tv: TVController
    @State private var reproduciendo = false

    private let plata = LinearGradient(
        colors: [Color(white: 0.93), Color(white: 0.74), Color(white: 0.86)],
        startPoint: .topLeading, endPoint: .bottomTrailing)
    private let negro = Color(red: 0.07, green: 0.07, blue: 0.08)

    var body: some View {
        ZStack(alignment: .top) {
            RoundedRectangle(cornerRadius: 46, style: .continuous)
                .fill(plata)
                .shadow(color: .white.opacity(0.10), radius: 30)
                .overlay(
                    RoundedRectangle(cornerRadius: 46, style: .continuous)
                        .stroke(Color.white.opacity(0.5), lineWidth: 1)
                )

            VStack(spacing: 0) {
                // Fila superior: micro (agujero) y botón de encendido
                HStack {
                    Capsule().fill(Color.black.opacity(0.75)).frame(width: 6, height: 6).padding(.leading, 6)
                    Spacer()
                    Button { tv.comando(.turnOff) } label: {
                        Image(systemName: "power")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(.black.opacity(0.8))
                            .frame(width: 38, height: 38)
                            .overlay(Circle().stroke(Color.black.opacity(0.35), lineWidth: 1.5))
                    }
                }
                .padding(.top, 16).padding(.horizontal, 18)

                // Touchpad redondo
                Touchpad().padding(.top, 14)

                // Atrás y TV
                HStack(spacing: 14) {
                    boton("chevron.left") { tv.tecla(.back) }
                    boton("tv") { tv.tecla(.home) }
                }
                .padding(.top, 16)

                // Play/pause + mute a la izquierda, volumen a la derecha
                HStack(alignment: .top, spacing: 14) {
                    VStack(spacing: 14) {
                        boton(reproduciendo ? "pause.fill" : "playpause.fill") {
                            reproduciendo.toggle()
                            tv.comando(reproduciendo ? .play : .pause)
                        }
                        boton("speaker.slash.fill") { tv.tecla(.mute) }
                    }
                    VStack(spacing: 0) {
                        Button { tv.tecla(.volumeUp) } label: {
                            Image(systemName: "plus").font(.system(size: 22, weight: .medium))
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                        }
                        Button { tv.tecla(.volumeDown) } label: {
                            Image(systemName: "minus").font(.system(size: 22, weight: .medium))
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                        }
                    }
                    .foregroundColor(.white)
                    .frame(width: 74, height: 148)
                    .background(negro, in: RoundedRectangle(cornerRadius: 37, style: .continuous))
                }
                .padding(.top, 14)

                Spacer(minLength: 0)
            }
            .frame(width: 214)
            .padding(.top, 0)
        }
        .frame(width: 262, height: 560)
        .opacity(tv.conectada ? 1 : 0.55)
    }

    func boton(_ icono: String, _ accion: @escaping () -> Void) -> some View {
        Button(action: accion) {
            Image(systemName: icono)
                .font(.system(size: 20, weight: .medium))
                .foregroundColor(.white)
                .frame(width: 74, height: 74)
                .background(negro, in: Circle())
        }
        .buttonStyle(PulsarStyle())
    }
}

struct PulsarStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.93 : 1)
            .animation(.spring(response: 0.2, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

// MARK: - Touchpad: toca = OK, desliza = flechas
struct Touchpad: View {
    @EnvironmentObject var tv: TVController
    @State private var ultimo: CGSize = .zero
    @State private var pulsando = false
    @State private var movio = false
    private let paso: CGFloat = 38

    var body: some View {
        ZStack {
            Circle().fill(Color(red: 0.07, green: 0.07, blue: 0.08))
            Circle().fill(Color.white.opacity(pulsando ? 0.10 : 0)).padding(6)
            // Puntos de las 4 direcciones
            ForEach(0..<4) { i in
                Circle().fill(Color.white.opacity(0.85)).frame(width: 4, height: 4)
                    .offset(y: -86).rotationEffect(.degrees(Double(i) * 90))
            }
        }
        .frame(width: 196, height: 196)
        .contentShape(Circle())
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { v in
                    pulsando = true
                    let dx = v.translation.width - ultimo.width
                    let dy = v.translation.height - ultimo.height
                    if abs(dx) > paso || abs(dy) > paso {
                        movio = true
                        if abs(dx) > abs(dy) { tv.tecla(dx > 0 ? .right : .left) }
                        else { tv.tecla(dy > 0 ? .down : .up) }
                        ultimo = v.translation
                    }
                }
                .onEnded { _ in
                    if !movio { tv.tecla(.enter) }
                    movio = false; pulsando = false; ultimo = .zero
                }
        )
    }
}
