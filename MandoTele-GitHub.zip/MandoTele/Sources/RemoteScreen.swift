import SwiftUI
import WebOSClient

enum Pestana: CaseIterable {
    case mando, teclas, apps, ajustes

    var titulo: String {
        switch self {
        case .mando: return "Mando"
        case .teclas: return "Teclas"
        case .apps: return "Apps"
        case .ajustes: return "Ajustes"
        }
    }

    var icono: String {
        switch self {
        case .mando: return "circle.circle.fill"
        case .teclas: return "number.square.fill"
        case .apps: return "square.grid.2x2.fill"
        case .ajustes: return "gearshape.fill"
        }
    }
}

struct RemoteScreen: View {
    @EnvironmentObject var tv: TVController
    @State private var pestana: Pestana = .mando
    @State private var mostrarTeclado = false

    var body: some View {
        ZStack {
            fondo
            VStack(spacing: 10) {
                cabecera
                pantallaTele
                contenido
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                barraPestanas
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 8)
        }
        .sheet(isPresented: $mostrarTeclado) { TecladoView().environmentObject(tv) }
        .onAppear {
            if tv.ip.isEmpty { pestana = .ajustes }
            else if !tv.conectada { tv.conectar() }
        }
        .onChange(of: tv.status) { s in
            if s == .conectada { pestana = .mando }
        }
    }

    @ViewBuilder var contenido: some View {
        switch pestana {
        case .mando: MandoPagina()
        case .teclas: TeclasPagina()
        case .apps: AppsPagina()
        case .ajustes: AjustesPagina()
        }
    }

    // Fondo azul noche con una esfera brillante del color elegido
    var fondo: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.03, green: 0.05, blue: 0.16), Color(red: 0.0, green: 0.0, blue: 0.03)],
                           startPoint: .top, endPoint: .bottom)
            Circle()
                .fill(RadialGradient(colors: [tv.acento.opacity(0.55), .clear],
                                     center: .center, startRadius: 5, endRadius: 190))
                .frame(width: 420, height: 420)
                .offset(y: 70)
        }
        .ignoresSafeArea()
    }

    // Pantalla pequeña de tele: muestra la última acción enviada
    var pantallaTele: some View {
        VStack(spacing: 4) {
            Text(tv.conectada ? tv.ultima : tv.status.texto)
                .font(.system(size: 22, weight: .semibold, design: .rounded))
                .foregroundColor(.white)
                .lineLimit(1).minimumScaleFactor(0.6)
                .id(tv.ultima + tv.status.texto)
                .transition(.opacity.combined(with: .scale(scale: 0.92)))
            Text(tv.demo ? "Modo demo, sin tele" : (tv.conectada ? "Mando conectado" : "Ve a Ajustes para conectar"))
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.white.opacity(0.55))
        }
        .frame(maxWidth: .infinity).frame(height: 66)
        .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Color.white.opacity(0.12), lineWidth: 1))
        .animation(.easeOut(duration: 0.18), value: tv.ultima)
    }

    var cabecera: some View {
        HStack {
            Button { mostrarTeclado = true } label: {
                Image(systemName: "keyboard")
                    .font(.system(size: 15, weight: .semibold))
                    .frame(width: 36, height: 36)
                    .background(Color.white.opacity(0.14), in: Circle())
            }
            Spacer()
            Button { withAnimation { pestana = .ajustes } } label: {
                HStack(spacing: 6) {
                    Circle().fill(tv.conectada ? Color.green : Color.orange).frame(width: 8, height: 8)
                    Text(tv.tvName).font(.system(size: 16, weight: .semibold))
                    Image(systemName: "chevron.down").font(.system(size: 11, weight: .bold))
                }
                .padding(.horizontal, 14).padding(.vertical, 8)
                .background(Color.white.opacity(0.14), in: Capsule())
            }
            Spacer()
            Button { tv.comando(.screenOff) } label: {
                Image(systemName: "moon.fill")
                    .font(.system(size: 15, weight: .semibold))
                    .frame(width: 36, height: 36)
                    .background(Color.white.opacity(0.14), in: Circle())
            }
        }
        .foregroundColor(.white)
    }

    var barraPestanas: some View {
        HStack(spacing: 6) {
            ForEach(Pestana.allCases, id: \.self) { p in
                Button { withAnimation(.easeInOut(duration: 0.2)) { pestana = p } } label: {
                    VStack(spacing: 3) {
                        Image(systemName: p.icono).font(.system(size: 18, weight: .semibold))
                        Text(p.titulo).font(.system(size: 11, weight: .semibold))
                    }
                    .foregroundColor(pestana == p ? Color.white : Color.white.opacity(0.55))
                    .frame(maxWidth: .infinity).padding(.vertical, 8)
                    .background(pestana == p ? tv.acento.opacity(0.45) : Color.clear,
                                in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
            }
        }
        .padding(6)
        .background(Color.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
    }
}

struct MandoPagina: View {
    var body: some View {
        GeometryReader { g in
            let e = min(1, max(0.45, g.size.height / 570))
            SiriRemote()
                .scaleEffect(e)
                .frame(width: 262 * e, height: 560 * e)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}

// MARK: - Mando plateado igual que el Siri Remote
struct SiriRemote: View {
    @EnvironmentObject var tv: TVController
    @State private var reproduciendo = false

    private let plata = LinearGradient(
        colors: [Color(white: 0.93), Color(white: 0.74), Color(white: 0.86)],
        startPoint: .topLeading, endPoint: .bottomTrailing)
    private let negro = Color(red: 0.07, green: 0.07, blue: 0.08)

    var body: some View {
        ZStack(alignment: .top) {
            RoundedRectangle(cornerRadius: 46, style: .continuous)
                .fill(plata)
                .shadow(color: tv.acento.opacity(0.4), radius: 34)
                .overlay(
                    RoundedRectangle(cornerRadius: 46, style: .continuous)
                        .stroke(Color.white.opacity(0.5), lineWidth: 1)
                )

            VStack(spacing: 0) {
                HStack {
                    Capsule().fill(Color.black.opacity(0.75)).frame(width: 6, height: 6).padding(.leading, 6)
                    Spacer()
                    Button { tv.comando(.turnOff) } label: {
                        Image(systemName: "power")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(.black.opacity(0.8))
                            .frame(width: 38, height: 38)
                            .overlay(Circle().stroke(Color.black.opacity(0.35), lineWidth: 1.5))
                    }
                }
                .padding(.top, 16).padding(.horizontal, 18)

                Touchpad().padding(.top, 14)

                HStack(spacing: 14) {
                    boton("chevron.left") { tv.tecla(.back) }
                    boton("tv") { tv.tecla(.home) }
                }
                .padding(.top, 16)

                HStack(alignment: .top, spacing: 14) {
                    VStack(spacing: 14) {
                        boton(reproduciendo ? "pause.fill" : "play.fill") {
                            reproduciendo.toggle()
                            tv.comando(reproduciendo ? .play : .pause)
                        }
                        boton("speaker.slash.fill") { tv.tecla(.mute) }
                    }
                    VStack(spacing: 0) {
                        Button { tv.tecla(.volumeUp) } label: {
                            Image(systemName: "plus").font(.system(size: 22, weight: .medium))
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                        }
                        Button { tv.tecla(.volumeDown) } label: {
                            Image(systemName: "minus").font(.system(size: 22, weight: .medium))
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                        }
                    }
                    .foregroundColor(.white)
                    .frame(width: 74, height: 148)
                    .background(negro, in: RoundedRectangle(cornerRadius: 37, style: .continuous))
                }
                .padding(.top, 14)

                Spacer(minLength: 0)
            }
            .frame(width: 214)
        }
        .frame(width: 262, height: 560)
        .opacity(tv.conectada ? 1 : 0.7)
    }

    func boton(_ icono: String, _ accion: @escaping () -> Void) -> some View {
        Button(action: accion) {
            Image(systemName: icono)
                .font(.system(size: 20, weight: .medium))
                .foregroundColor(.white)
                .frame(width: 74, height: 74)
                .background(negro, in: Circle())
        }
        .buttonStyle(PulsarStyle())
    }
}

struct PulsarStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.93 : 1)
            .animation(.spring(response: 0.2, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

// MARK: - Touchpad: toca = OK, desliza = flechas
struct Touchpad: View {
    @EnvironmentObject var tv: TVController
    @State private var ultimo: CGSize = .zero
    @State private var pulsando = false
    @State private var movio = false
    private let paso: CGFloat = 38

    var body: some View {
        ZStack {
            Circle().fill(Color(red: 0.07, green: 0.07, blue: 0.08))
            Circle().fill(Color.white.opacity(pulsando ? 0.12 : 0)).padding(6)
            ForEach(0..<4) { i in
                Circle().fill(Color.white.opacity(0.85)).frame(width: 4, height: 4)
                    .offset(y: -86).rotationEffect(.degrees(Double(i) * 90))
            }
        }
        .frame(width: 196, height: 196)
        .contentShape(Circle())
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { v in
                    pulsando = true
                    let dx = v.translation.width - ultimo.width
                    let dy = v.translation.height - ultimo.height
                    if abs(dx) > paso || abs(dy) > paso {
                        movio = true
                        if abs(dx) > abs(dy) { tv.tecla(dx > 0 ? .right : .left) }
                        else { tv.tecla(dy > 0 ? .down : .up) }
                        ultimo = v.translation
                    }
                }
                .onEnded { _ in
                    if !movio { tv.tecla(.enter) }
                    movio = false; pulsando = false; ultimo = .zero
                }
        )
    }
}
