import SwiftUI
import WebOSClient

struct RemoteScreen: View {
    @EnvironmentObject var tv: TVController
    @State private var mostrarTeclado = false
    @State private var mostrarApps = false
    @State private var mostrarConexion = false

    var body: some View {
        GeometryReader { geo in
            let escala = min(1, max(0.5, (geo.size.height - 250) / 560))
            ZStack {
                fondo
                VStack(spacing: 12) {
                    cabecera
                    pantallaTele
                    Spacer(minLength: 0)
                    SiriRemote()
                        .scaleEffect(escala)
                        .frame(width: 262 * escala, height: 560 * escala)
                    Spacer(minLength: 0)
                    barraInferior
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 8)
            }
        }
        .sheet(isPresented: $mostrarConexion) { ConexionView().environmentObject(tv) }
        .sheet(isPresented: $mostrarTeclado) { TecladoView().environmentObject(tv) }
        .sheet(isPresented: $mostrarApps) { AppsView().environmentObject(tv) }
        .onAppear {
            if tv.ip.isEmpty { mostrarConexion = true }
            else if !tv.conectada { tv.conectar() }
        }
    }

    // Fondo azul noche con una esfera brillante detrás del mando
    var fondo: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.03, green: 0.05, blue: 0.16), Color(red: 0.0, green: 0.0, blue: 0.03)],
                           startPoint: .top, endPoint: .bottom)
            Circle()
                .fill(RadialGradient(colors: [Color(red: 0.25, green: 0.55, blue: 1.0).opacity(0.55), .clear],
                                     center: .center, startRadius: 5, endRadius: 190))
                .frame(width: 420, height: 420)
                .offset(y: 70)
        }
        .ignoresSafeArea()
    }

    // Pantalla pequeña de tele: muestra la última acción enviada
    var pantallaTele: some View {
        VStack(spacing: 4) {
            Text(tv.conectada ? tv.ultima : tv.status.texto)
                .font(.system(size: 22, weight: .semibold, design: .rounded))
                .foregroundColor(.white)
                .lineLimit(1).minimumScaleFactor(0.6)
                .id(tv.ultima + tv.status.texto)
                .transition(.opacity.combined(with: .scale(scale: 0.92)))
            Text(tv.demo ? "Modo demo, sin tele" : (tv.conectada ? "Mando conectado" : "Toca el engranaje para conectar"))
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.white.opacity(0.55))
        }
        .frame(maxWidth: .infinity).frame(height: 74)
        .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Color.white.opacity(0.12), lineWidth: 1))
        .animation(.easeOut(duration: 0.18), value: tv.ultima)
    }

    // Cabecera como la app Mando de Apple
    var cabecera: some View {
        HStack {
            Button { mostrarConexion = true } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 15, weight: .semibold))
                    .frame(width: 36, height: 36)
                    .background(Color.white.opacity(0.14), in: Circle())
            }
            Spacer()
            Button { mostrarConexion = true } label: {
                HStack(spacing: 6) {
                    Circle().fill(tv.conectada ? Color.green : Color.orange).frame(width: 8, height: 8)
                    Text(tv.tvName).font(.system(size: 16, weight: .semibold))
                    Image(systemName: "chevron.down").font(.system(size: 11, weight: .bold))
                }
                .padding(.horizontal, 14).padding(.vertical, 8)
                .background(Color.white.opacity(0.14), in: Capsule())
            }
            Spacer()
            Color.clear.frame(width: 36, height: 36)
        }
        .foregroundColor(.white)
    }

    var barraInferior: some View {
        HStack(spacing: 14) {
            pastilla("keyboard", "Teclado") { mostrarTeclado = true }
            pastilla("square.grid.2x2.fill", "Apps") { mostrarApps = true }
        }
    }

    func pastilla(_ icono: String, _ texto: String, _ accion: @escaping () -> Void) -> some View {
        Button(action: accion) {
            HStack(spacing: 8) {
                Image(systemName: icono)
                Text(texto).font(.system(size: 16, weight: .semibold))
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity).padding(.vertical, 14)
            .background(Color.white.opacity(0.14), in: Capsule())
        }
        .buttonStyle(PulsarStyle())
    }
}

// MARK: - Mando plateado igual que el Siri Remote
struct SiriRemote: View {
    @EnvironmentObject var tv: TVController
    @State private var reproduciendo = false

    private let plata = LinearGradient(
        colors: [Color(white: 0.93), Color(white: 0.74), Color(white: 0.86)],
        startPoint: .topLeading, endPoint: .bottomTrailing)
    private let negro = Color(red: 0.07, green: 0.07, blue: 0.08)

    var body: some View {
        ZStack(alignment: .top) {
            RoundedRectangle(cornerRadius: 46, style: .continuous)
                .fill(plata)
                .shadow(color: Color(red: 0.3, green: 0.6, blue: 1).opacity(0.35), radius: 34)
                .overlay(
                    RoundedRectangle(cornerRadius: 46, style: .continuous)
                        .stroke(Color.white.opacity(0.5), lineWidth: 1)
                )

            VStack(spacing: 0) {
                HStack {
                    Capsule().fill(Color.black.opacity(0.75)).frame(width: 6, height: 6).padding(.leading, 6)
                    Spacer()
                    Button { tv.comando(.turnOff) } label: {
                        Image(systemName: "power")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(.black.opacity(0.8))
                            .frame(width: 38, height: 38)
                            .overlay(Circle().stroke(Color.black.opacity(0.35), lineWidth: 1.5))
                    }
                }
                .padding(.top, 16).padding(.horizontal, 18)

                Touchpad().padding(.top, 14)

                HStack(spacing: 14) {
                    boton("chevron.left") { tv.tecla(.back) }
                    boton("tv") { tv.tecla(.home) }
                }
                .padding(.top, 16)

                HStack(alignment: .top, spacing: 14) {
                    VStack(spacing: 14) {
                        boton(reproduciendo ? "pause.fill" : "play.fill") {
                            reproduciendo.toggle()
                            tv.comando(reproduciendo ? .play : .pause)
                        }
                        boton("speaker.slash.fill") { tv.tecla(.mute) }
                    }
                    VStack(spacing: 0) {
                        Button { tv.tecla(.volumeUp) } label: {
                            Image(systemName: "plus").font(.system(size: 22, weight: .medium))
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                        }
                        Button { tv.tecla(.volumeDown) } label: {
                            Image(systemName: "minus").font(.system(size: 22, weight: .medium))
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                        }
                    }
                    .foregroundColor(.white)
                    .frame(width: 74, height: 148)
                    .background(negro, in: RoundedRectangle(cornerRadius: 37, style: .continuous))
                }
                .padding(.top, 14)

                Spacer(minLength: 0)
            }
            .frame(width: 214)
        }
        .frame(width: 262, height: 560)
        .opacity(tv.conectada ? 1 : 0.7)
    }

    func boton(_ icono: String, _ accion: @escaping () -> Void) -> some View {
        Button(action: accion) {
            Image(systemName: icono)
                .font(.system(size: 20, weight: .medium))
                .foregroundColor(.white)
                .frame(width: 74, height: 74)
                .background(negro, in: Circle())
        }
        .buttonStyle(PulsarStyle())
    }
}

struct PulsarStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.93 : 1)
            .animation(.spring(response: 0.2, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

// MARK: - Touchpad: toca = OK, desliza = flechas
struct Touchpad: View {
    @EnvironmentObject var tv: TVController
    @State private var ultimo: CGSize = .zero
    @State private var pulsando = false
    @State private var movio = false
    private let paso: CGFloat = 38

    var body: some View {
        ZStack {
            Circle().fill(Color(red: 0.07, green: 0.07, blue: 0.08))
            Circle().fill(Color.white.opacity(pulsando ? 0.12 : 0)).padding(6)
            ForEach(0..<4) { i in
                Circle().fill(Color.white.opacity(0.85)).frame(width: 4, height: 4)
                    .offset(y: -86).rotationEffect(.degrees(Double(i) * 90))
            }
        }
        .frame(width: 196, height: 196)
        .contentShape(Circle())
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { v in
                    pulsando = true
                    let dx = v.translation.width - ultimo.width
                    let dy = v.translation.height - ultimo.height
                    if abs(dx) > paso || abs(dy) > paso {
                        movio = true
                        if abs(dx) > abs(dy) { tv.tecla(dx > 0 ? .right : .left) }
                        else { tv.tecla(dy > 0 ? .down : .up) }
                        ultimo = v.translation
                    }
                }
                .onEnded { _ in
                    if !movio { tv.tecla(.enter) }
                    movio = false; pulsando = false; ultimo = .zero
                }
        )
    }
}
