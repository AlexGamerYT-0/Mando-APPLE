import SwiftUI
import WebOSClient

enum TVStatus: Equatable {
    case desconectada
    case conectando
    case aceptaEnLaTele
    case conectada
    case error(String)

    var texto: String {
        switch self {
        case .desconectada: return "Sin conexión"
        case .conectando: return "Conectando…"
        case .aceptaEnLaTele: return "Acepta el aviso en la tele"
        case .conectada: return "Conectada"
        case .error(let m): return m
        }
    }
}

final class TVController: NSObject, ObservableObject, WebOSClientDelegate {
    @Published var ip: String = UserDefaults.standard.string(forKey: "tvIP") ?? ""
    @Published var status: TVStatus = .desconectada
    @Published var tvName: String = "LG TV"

    private var client: WebOSClientProtocol?
    private let keyName = "clientKey"
    private var reconnects = 0

    var conectada: Bool { status == .conectada }

    // MARK: Conexión
    func conectar() {
        let limpia = ip.trimmingCharacters(in: .whitespaces)
        guard !limpia.isEmpty, let url = URL(string: "wss://\(limpia):3001") else {
            status = .error("Escribe la IP de la tele")
            return
        }
        UserDefaults.standard.set(limpia, forKey: "tvIP")
        status = .conectando
        client?.disconnect()
        client = WebOSClient(url: url, delegate: self, shouldLogActivity: false)
        client?.connect()
        let token = UserDefaults.standard.string(forKey: keyName)
        client?.send(.register(pairingType: .prompt, clientKey: token))
    }

    func desconectar() {
        client?.disconnect()
        status = .desconectada
    }

    // MARK: Mando
    func tecla(_ k: WebOSKeyTarget) {
        haptic()
        client?.sendKey(k)
    }

    func comando(_ t: WebOSTarget) {
        haptic()
        client?.send(t)
    }

    func escribir(_ texto: String) {
        client?.send(.registerRemoteKeyboard)
        client?.send(.insertText(text: texto, replace: true))
    }

    func enter() { client?.send(.sendEnterKey) }
    func borrar() { client?.send(.deleteCharacters(count: 1)) }

    func abrir(_ id: String) { comando(.launchApp(appId: id)) }

    private func haptic() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    // MARK: WebOSClientDelegate
    func didConnect() {}

    func didDisplayPin() {}

    func didPrompt() {
        DispatchQueue.main.async { self.status = .aceptaEnLaTele }
    }

    func didRegister(with clientKey: String) {
        UserDefaults.standard.set(clientKey, forKey: keyName)
        DispatchQueue.main.async {
            self.status = .conectada
            self.reconnects = 0
        }
    }

    func didReceive(_ result: Result<WebOSResponse, Error>) {
        DispatchQueue.main.async {
            switch result {
            case .failure(let e):
                let m = e.localizedDescription
                if m.contains("rejected pairing") { self.status = .error("Rechazaste el emparejamiento") }
                else if m.contains("cancelled") { self.status = .error("Se acabó el tiempo. Vuelve a probar") }
            case .success: break
            }
        }
    }

    func didReceiveNetworkError(_ error: Error?) {
        DispatchQueue.main.async {
            if self.reconnects < 3, self.status == .conectada || self.status == .conectando {
                self.reconnects += 1
                self.conectar()
            } else {
                self.status = .error("Se perdió la conexión")
            }
        }
    }

    func didDisconnect() {
        DispatchQueue.main.async {
            if self.status == .conectada { self.status = .desconectada }
        }
    }
}
