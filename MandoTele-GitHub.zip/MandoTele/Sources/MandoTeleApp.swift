import SwiftUI

@main
struct MandoTeleApp: App {
    @StateObject private var tv = TVController()

    var body: some Scene {
        WindowGroup {
            RemoteScreen()
                .environmentObject(tv)
                .preferredColorScheme(.dark)
        }
    }
}
