import SwiftUI
import WebOSClient

// Botón de cristal reutilizable
struct Cristal<Contenido: View>: View {
    let color: Color
    let alto: CGFloat
    let accion: () -> Void
    let contenido: Contenido

    init(color: Color = Color.white.opacity(0.12), alto: CGFloat = 54,
         accion: @escaping () -> Void, @ViewBuilder contenido: () -> Contenido) {
        self.color = color
        self.alto = alto
        self.accion = accion
        self.contenido = contenido()
    }

    var body: some View {
        Button(action: accion) {
            contenido
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .frame(height: alto)
                .background(color, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(PulsarStyle())
    }
}

struct Tarjeta<Contenido: View>: View {
    let contenido: Contenido
    init(@ViewBuilder contenido: () -> Contenido) { self.contenido = contenido() }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) { contenido }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

func titulo(_ t: String) -> some View {
    Text(t).font(.system(size: 15, weight: .semibold)).foregroundColor(.white.opacity(0.7))
}

// MARK: - Teclas clásicas
struct TeclasPagina: View {
    @EnvironmentObject var tv: TVController

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 12) {
                HStack(spacing: 10) {
                    Cristal(accion: { tv.tecla(.info) }) { Text("Info").font(.system(size: 17, weight: .semibold)) }
                    Cristal(accion: { tv.tecla(.menu) }) { Text("Menú").font(.system(size: 17, weight: .semibold)) }
                    Cristal(accion: { tv.tecla(.exit) }) { Text("Salir").font(.system(size: 17, weight: .semibold)) }
                }

                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 3), spacing: 10) {
                    ForEach(1..<10, id: \.self) { n in
                        Cristal(accion: { tv.numero(n) }) {
                            Text("\(n)").font(.system(size: 22, weight: .semibold, design: .rounded))
                        }
                    }
                }
                HStack(spacing: 10) {
                    Cristal(accion: { tv.tecla(.dash) }) { Text("–").font(.system(size: 22, weight: .semibold)) }
                    Cristal(accion: { tv.numero(0) }) { Text("0").font(.system(size: 22, weight: .semibold, design: .rounded)) }
                    Cristal(accion: { tv.tecla(.mute) }) { Image(systemName: "speaker.slash.fill") }
                }

                HStack(spacing: 10) {
                    VStack(spacing: 8) {
                        titulo("Canal")
                        Cristal(accion: { tv.tecla(.channelUp) }) { Image(systemName: "chevron.up") }
                        Cristal(accion: { tv.tecla(.channelDown) }) { Image(systemName: "chevron.down") }
                    }
                    VStack(spacing: 8) {
                        titulo("Volumen")
                        Cristal(accion: { tv.tecla(.volumeUp) }) { Image(systemName: "plus") }
                        Cristal(accion: { tv.tecla(.volumeDown) }) { Image(systemName: "minus") }
                    }
                }

                HStack(spacing: 8) {
                    Cristal(accion: { tv.tecla(.rewind) }) { Image(systemName: "backward.fill") }
                    Cristal(accion: { tv.tecla(.play) }) { Image(systemName: "play.fill") }
                    Cristal(accion: { tv.tecla(.pause) }) { Image(systemName: "pause.fill") }
                    Cristal(accion: { tv.tecla(.stop) }) { Image(systemName: "stop.fill") }
                    Cristal(accion: { tv.tecla(.fastForward) }) { Image(systemName: "forward.fill") }
                }

                HStack(spacing: 10) {
                    Cristal(color: Color.red.opacity(0.85), alto: 38, accion: { tv.tecla(.red) }) { EmptyView() }
                    Cristal(color: Color.green.opacity(0.85), alto: 38, accion: { tv.tecla(.green) }) { EmptyView() }
                    Cristal(color: Color.yellow.opacity(0.85), alto: 38, accion: { tv.tecla(.yellow) }) { EmptyView() }
                    Cristal(color: Color.blue.opacity(0.85), alto: 38, accion: { tv.tecla(.blue) }) { EmptyView() }
                }
                .padding(.bottom, 6)
            }
        }
    }
}

// MARK: - Apps, escenas, entradas y mensajes
struct AppsPagina: View {
    @EnvironmentObject var tv: TVController
    @State private var mensaje = ""

    private let apps: [(String, String, String, Color)] = [
        ("Netflix", "netflix", "n.circle.fill", Color.red),
        ("YouTube", "youtube.leanback.v4", "play.rectangle.fill", Color.red),
        ("Prime Video", "amazon", "a.circle.fill", Color.cyan),
        ("Disney+", "com.disney.disneyplus-prod", "sparkles", Color.blue),
        ("TV en directo", "com.webos.app.livetv", "tv.fill", Color.green),
        ("Navegador", "com.webos.app.browser", "safari.fill", Color.orange)
    ]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                titulo("Escenas")
                HStack(spacing: 10) {
                    escena(0, "Cine", "film.fill")
                    escena(1, "Música", "music.note")
                    escena(2, "Buenas noches", "moon.stars.fill")
                }

                titulo("Apps")
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 3), spacing: 10) {
                    ForEach(0..<apps.count, id: \.self) { i in
                        Cristal(alto: 84, accion: { tv.abrir(apps[i].1) }) {
                            VStack(spacing: 6) {
                                Image(systemName: apps[i].2).font(.system(size: 26)).foregroundColor(apps[i].3)
                                Text(apps[i].0).font(.system(size: 11, weight: .semibold)).lineLimit(1)
                            }
                        }
                    }
                }

                titulo("Entradas")
                HStack(spacing: 10) {
                    ForEach(1..<4, id: \.self) { n in
                        Cristal(accion: { tv.entrada("HDMI_\(n)") }) {
                            Text("HDMI \(n)").font(.system(size: 15, weight: .semibold))
                        }
                    }
                }

                titulo("Mensaje en la tele")
                HStack(spacing: 10) {
                    TextField("Escribe algo…", text: $mensaje)
                        .padding(12)
                        .foregroundColor(.white)
                        .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    Cristal(color: tv.acento.opacity(0.8), accion: {
                        guard !mensaje.isEmpty else { return }
                        tv.mensaje(mensaje)
                        mensaje = ""
                    }) { Text("Enviar").font(.system(size: 15, weight: .semibold)) }
                    .frame(width: 90)
                }
                .padding(.bottom, 6)
            }
        }
    }

    func escena(_ n: Int, _ nombre: String, _ icono: String) -> some View {
        Cristal(alto: 78, accion: { tv.escena(n) }) {
            VStack(spacing: 6) {
                Image(systemName: icono).font(.system(size: 22))
                Text(nombre).font(.system(size: 12, weight: .semibold)).lineLimit(1).minimumScaleFactor(0.7)
            }
        }
    }
}

// MARK: - Ajustes
struct AjustesPagina: View {
    @EnvironmentObject var tv: TVController

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 12) {
                Tarjeta {
                    titulo("Tu tele LG")
                    TextField("IP de la tele (ej. 192.168.1.20)", text: $tv.ip)
                        .keyboardType(.numbersAndPunctuation)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                        .padding(12)
                        .foregroundColor(.white)
                        .background(Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    HStack(spacing: 10) {
                        Cristal(color: tv.acento.opacity(0.8), accion: { tv.conectar() }) {
                            Text("Conectar").font(.system(size: 16, weight: .semibold))
                        }
                        if tv.conectada {
                            Cristal(accion: { tv.desconectar() }) {
                                Text("Desconectar").font(.system(size: 16, weight: .semibold))
                            }
                        }
                    }
                    Cristal(accion: { tv.activarDemo() }) {
                        Text("Probar sin tele (modo demo)").font(.system(size: 15, weight: .semibold))
                    }
                    Text("Estado: \(tv.demo ? "Modo demo" : tv.status.texto)")
                        .font(.footnote).foregroundColor(.white.opacity(0.7))
                    Text("La IP está en la tele: Ajustes → Red → Wi-Fi → Avanzado. Activa «LG Connect Apps» en Ajustes → General. La primera vez acepta el aviso en la pantalla de la tele.")
                        .font(.caption).foregroundColor(.white.opacity(0.5))
                }

                Tarjeta {
                    HStack {
                        titulo("Volumen")
                        Spacer()
                        Text("\(Int(tv.volumen))").font(.system(size: 15, weight: .semibold, design: .rounded)).foregroundColor(.white)
                    }
                    Slider(value: $tv.volumen, in: 0...100, step: 1) { editando in
                        if !editando { tv.fijarVolumen(Int(tv.volumen)) }
                    }
                    .tint(tv.acento)
                }

                Tarjeta {
                    titulo("Color del mando")
                    HStack(spacing: 14) {
                        ForEach(0..<5, id: \.self) { i in
                            Circle()
                                .fill(color(i))
                                .frame(width: 38, height: 38)
                                .overlay(Circle().stroke(Color.white, lineWidth: tv.tema == i ? 3 : 0))
                                .onTapGesture { tv.tema = i }
                        }
                        Spacer()
                    }
                    Toggle("Vibración al pulsar", isOn: $tv.vibracion)
                        .foregroundColor(.white)
                        .tint(tv.acento)
                }
                .padding(.bottom, 6)
            }
        }
    }

    func color(_ i: Int) -> Color {
        let c: [Color] = [
            Color(red: 0.25, green: 0.55, blue: 1.0),
            Color(red: 0.62, green: 0.35, blue: 1.0),
            Color(red: 0.20, green: 0.85, blue: 0.55),
            Color(red: 1.00, green: 0.35, blue: 0.60),
            Color(red: 1.00, green: 0.60, blue: 0.20)
        ]
        return c[i]
    }
}
