import SwiftUI

struct TecladoView: View {
    @EnvironmentObject var tv: TVController
    @Environment(\.dismiss) private var dismiss
    @State private var texto = ""
    @FocusState private var foco: Bool

    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                TextField("Escribe en la tele", text: $texto)
                    .textFieldStyle(.roundedBorder)
                    .focused($foco)
                    .submitLabel(.send)
                    .onChange(of: texto) { nuevo in tv.escribir(nuevo) }
                    .onSubmit { tv.enter(); dismiss() }
                Text("Abre antes un cuadro de texto en la tele (por ejemplo, el buscador).")
                    .font(.footnote).foregroundColor(.secondary)
                Spacer()
            }
            .padding()
            .navigationTitle("Teclado")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cerrar") { dismiss() } } }
            .onAppear { foco = true }
        }
    }
}
